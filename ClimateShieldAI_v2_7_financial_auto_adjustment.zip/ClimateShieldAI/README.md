# ClimateShield AI — Secure Climate Intelligence Platform

Developed by **Team KhulshayxCipher**. The product/model identity is **ClimateShield AI**.

## Current implementation status
- Redesigned responsive dashboard.
- FastAPI API with strict Pydantic input schemas and optional API-key gate.
- SQLAlchemy database layer supporting SQLite for local development and PostgreSQL via `DATABASE_URL` for deployment.
- Database-level unique constraint for idempotent actions; payload mismatch returns HTTP 409.
- Server-ingress timestamp collection and external C02 verification script.
- SHA-256 canonical payload fingerprints and linked audit records.
- NASA POWER Pakistan multi-location data downloader.
- Exploratory Random Forest training pipeline using explicitly labelled proxy outcomes.

**Honesty note:** climate prediction endpoint currently serves a transparent rule-based baseline. The NASA downloader and training pipeline are included, but a model is not considered validated until data is downloaded, labels are replaced/verified against observed disaster outcomes, and evaluation is reviewed. Do not use this for real-world emergency decisions.

## Local setup (Kali / Ubuntu / Windows)
1. Install Python 3.11+ and PostgreSQL if using production DB.
2. Extract project and open terminal in project folder.
3. Create environment: `python -m venv .venv`
4. Activate: Linux `source .venv/bin/activate`; Windows `.venv\Scripts\activate`
5. Install: `python -m pip install -r requirements.txt`
6. Copy `.env.example` to `.env`; configure a strong `APP_API_KEY`; the application loads `.env` automatically.
7. Start: `uvicorn app.main:app --host 127.0.0.1 --port 8000 --no-server-header`
8. Open dashboard `http://127.0.0.1:8000` and API docs `http://127.0.0.1:8000/docs`.

For local development, no API key is required unless `APP_API_KEY` is set. When set, enter it in browser devtools: `localStorage.setItem('climateshield_api_key','YOUR_KEY')`, then reload. In production set `APP_ENV=production`, a strong key, and PostgreSQL. Put the service behind HTTPS and a reverse proxy; never expose development mode publicly.

## C02 verification
Terminal A: start API. Terminal B:
`python scripts/c02_stress_test.py`

The script sends 30 ingress-marker requests concurrently, reads server-side monotonic timestamps, then sends 30 action requests sharing one idempotency key. A PASS requires (a) 30 ingress records, (b) server-observed spread <=20 ms, (c) exactly one committed action, (d) 29 duplicate rejections, and (e) zero duplicate commits. A run that misses the 20 ms target is a FAIL, not a pass. Network/OS scheduling can make the 20 ms target nondeterministic; repeat and retain raw output. Also run `POST /api/stress-test` for an in-process database race test.

## Pakistan climate data pipeline
NASA POWER daily point API source: `https://power.larc.nasa.gov/api/temporal/daily/point`

Fetch a Pakistan sample grid (10 locations):
`python scripts/fetch_nasa_power.py --start 20190101 --end 20251231`

Output: `data/raw/nasa_power_pakistan.csv`. Parameters: corrected precipitation (`PRECTOTCORR`), 2m temperature (`T2M`) and relative humidity (`RH2M`). These are gridded/reanalysis or satellite-derived estimates, not ground-station truth. Add CHIRPS rainfall and official disaster labels before claiming flood-event predictive performance.

Train exploratory baseline:
`python scripts/train_baseline.py`

The included label is a heuristic (rainfall >=50 mm OR temperature >=40 C), not a verified disaster label. It is only a pipeline smoke test. For research-grade ML, join district/date records with verified NDMA/PDMA disaster events, split chronologically and geographically, evaluate precision/recall/F1 and calibration, and document data leakage controls.

## Tests
`pytest -q`

## Deployment guidance
- Use PostgreSQL, TLS termination, secrets manager/environment variables, restricted network access, backups, and monitoring.
- Use separate database roles with least privilege.
- Add rate limiting at reverse proxy/API gateway and rotate API keys.
- Do not store personal banking/customer records. The finance endpoint is aggregate-only and the demo has no differential privacy guarantee.
- Audit hash chaining is tamper-evident only if the chain head is externally anchored; an administrator with DB write access could rewrite the entire chain.
- Before multi-worker production, run load tests against PostgreSQL and confirm migration/backup procedures.

### Run C02 from the dashboard

Open the dashboard, navigate to **C02 concurrency verification**, and click **RUN C02 CONCURRENCY TEST**. The browser sends 30 concurrent authenticated HTTP requests to the arrival endpoint, reads the server-observed arrival spread, and then sends 30 concurrent requests using one shared idempotency key. The dashboard reports PASS only when all 30 markers arrive within 20 ms, exactly one action commits, 29 duplicates are rejected, and duplicate commits remain zero. The terminal script `python scripts/c02_stress_test.py` remains available for command-line testing.


## C02 concurrency test (arrival window ≤ 20 ms)
Browsers send HTTP/1.1 requests over at most 6 connections per host, so 30 requests arrive in queued waves (~30 ms+).
For a reliable pass, run the app over **HTTP/2** and open the dashboard over HTTPS:

1. `pip install -r requirements.txt`
2. Windows: `run_https.bat`   Linux/macOS: `./run_https.sh`   (creates a self-signed cert on first run)
3. Open `https://localhost:8443`, click *Advanced → Proceed to localhost* once, then run the C02 test.

The dashboard opens 30 HTTP/2 streams on one connection, sends all headers, withholds the bodies, then releases all 30 bodies
in one loop ("last-byte sync"). The server stamps each request when it is complete; the result card also shows the
header-arrival spread. Keep a single server process (arrival timestamps are in memory). Plain `uvicorn` on port 8000 still works
(HTTP/1.1, sharded across `c1..c5.localhost`) but cannot guarantee ≤ 20 ms.


## C07 — Hardened error & information-leakage defense
- Every failure (unhandled exception, 4xx/5xx, validation error, unknown route, wrong method) returns the same envelope:
  `{"error":{"code":"INTERNAL_ERROR","message":"<generic>","error_id":"ERR-1A2B3C4D5E6F"}}` plus an `X-Error-ID` header.
- The full diagnostic record (exception type/message, traceback, request path/query/IP/user-agent, runtime versions, Pydantic detail) is written as JSON lines to `logs/error_audit.log` (`ERROR_AUDIT_LOG` to relocate). It is not served by any endpoint; operators match a client's error ID to the log.
- `Server`/`X-Powered-By` headers are stripped; run uvicorn with `--no-server-header` (Hypercorn: `hypercorn.toml`). In production `/docs` and `/openapi.json` are disabled.
- Verify from the dashboard (**C07 error defense** -> *Run C07 error-leakage test*; *Show raw client response* displays exactly what an attacker sees), or from a terminal with the API running: `python scripts/c07_error_leak_test.py`. Automated tests: `pytest -q`.
- Protect `logs/` with filesystem permissions (owner-only) and ship it to your central log store; it contains sensitive diagnostics by design.

## C13 — Adversarial model / logic evasion defense
- **Blind spot:** shaving a few points off non-critical inputs (humidity/temperature) slides a true `HIGH` (66.0) under the 65 cut-off (humidity 78 -> 74 returns 64.8 `MEDIUM`) while every field stays in range, so schema validation never fires.
- **Defense (`app/defense.py`, fail-safe: can only raise a category):** physical-consistency humidity clamp under heavy rain, perturbation-stability margin (humidity +10 / temperature +3 budget), critical-evidence floor (rainfall+river >= 55/75 -> `HIGH`), and a boundary-probing detector. `/api/climate/predict` now returns a `defense` object (`raw_category`, `flags`, `review_required`); raised categories and triggers are written to the audit chain.
- **Evidence:** `python scripts/c13_adversarial_test.py` (no server needed) or dashboard -> *C13 evasion defense*. In-budget attacker: 986/9,572 evaded before -> 0 after. Out-of-budget attacks are only partly stopped (27.6% -> 9.0%); see `docs/C13_ADVERSARIAL_DEFENSE.md` for limits and trade-offs.

const $=id=>document.getElementById(id);async function api(path,opts={}){const headers={'Content-Type':'application/json'};const key=localStorage.getItem('climateshield_api_key');if(key)headers['X-API-Key']=key;const r=await fetch(path,{...opts,headers:{...headers,...opts.headers}});let d={};try{d=await r.json()}catch{}if(!r.ok){const e=d.error;throw Error(e?`${e.message} (Error ID: ${e.error_id})`:(d.detail||r.statusText))}return d}function show(id,data){$(id).innerHTML=typeof data==='string'?data:`<pre>${JSON.stringify(data,null,2)}</pre>`}async function refresh(){try{const h=await api('/api/health');$('apiStatus').textContent='SYSTEM ONLINE';$('status').textContent='ONLINE';$('database').textContent=h.database.toUpperCase();const s=await api('/api/stats');$('shares').textContent=s.privacy_shares;$('audits').textContent=s.audit_events}catch(e){$('apiStatus').textContent='AUTH / API CHECK';$('status').textContent='CHECK CONFIG'}}
$('climateForm').onsubmit=async e=>{
 e.preventDefault();
 const o=Object.fromEntries(new FormData(e.target));
 for(const k of ['rainfall_mm','temperature_c','humidity_pct','river_level_m'])o[k]=Number(o[k]);
 try{
  const r=await api('/api/climate/predict',{method:'POST',body:JSON.stringify(o)});
  $('climateResult').innerHTML=`<div class="risk ${r.risk_category.toLowerCase()}">${r.risk_score}/100</div><b>${r.risk_category} BASELINE RISK</b><p>${r.model_note}</p>${r.defense&&r.defense.flags.length?`<p><b>C13 flags:</b> ${r.defense.flags.join(', ')}${r.defense.escalated?` — raw baseline said ${r.defense.raw_category}`:''}</p>`:''}<small>SHA-256: ${r.input_hash}</small><p>${r.warning}</p>`;
  const financeForm=$('shareForm');
  const institution=financeForm.elements.institution.value.trim();
  const district=o.district;
  financeForm.elements.district.value=o.district;
  const base=Number(financeForm.elements.exposure_amount.value);
  if(institution&&district&&Number.isFinite(base)&&base>0){
   const f=await api('/api/privacy/risk-adjust',{method:'POST',body:JSON.stringify({
    institution,district,base_exposure:base,risk_category:r.risk_category
   })});
   $('riskFinanceResult').innerHTML=`<b>Automatic financial adjustment completed</b><p>Risk: ${f.risk_category} × ${f.multiplier.toFixed(1)}</p><p>Base exposure: PKR ${f.base_exposure.toLocaleString()}</p><p><strong>Risk-adjusted exposure: PKR ${f.adjusted_exposure.toLocaleString()}</strong></p>`;
   await loadSummary();
  }else{
   $('riskFinanceResult').textContent='Enter a valid institution and base exposure in Institutional Aggregates to enable automatic financial adjustment.';
  }
  loadAudit();refresh();
 }catch(x){show('climateResult','Request rejected: '+x.message);$('riskFinanceResult').textContent='Financial adjustment was not completed.'}
};$('shareForm').onsubmit=async e=>{e.preventDefault();const o=Object.fromEntries(new FormData(e.target));o.exposure_amount=Number(o.exposure_amount);try{show('shareResult',await api('/api/privacy/share',{method:'POST',body:JSON.stringify(o)}));loadSummary();loadAudit();refresh()}catch(x){show('shareResult','Request rejected: '+x.message)}};
async function loadSummary(){try{const d=await api('/api/privacy/summary');show('summary',d.aggregates.length?d.aggregates:'No aggregate records yet.')}catch(e){show('summary',e.message)}}async function loadAudit(){try{const rows=await api('/api/audit');$('auditList').innerHTML=rows.length?rows.map(x=>`<div class="auditrow"><b>${x.event_type}</b><br>${x.summary}<br><code>${x.event_hash}</code></div>`).join(''):'No audit events yet.';const v=await api('/api/audit/verify');$('auditVerify').textContent=`Chain verification: ${v.valid?'VALID':'INVALID'} • ${v.events_verified??0} events`}catch(e){$('auditList').textContent=e.message}}
$('refreshSummary').onclick=loadSummary;$('refreshAudit').onclick=loadAudit;refresh();loadSummary();loadAudit();

$('runC02').onclick=async()=>{
 const button=$('runC02'), output=$('stressResult');
 button.disabled=true;button.textContent='TEST RUNNING…';
 output.textContent='Sending 30 concurrent arrival requests…';
 const runId=(crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random().toString(16).slice(2)}`);
 const sharedKey=`c02-ui-${runId}`;
 try{
  const apiKey=localStorage.getItem('climateshield_api_key')||'';
  const bodies=Array.from({length:30},(_,i)=>JSON.stringify({run_id:runId,request_id:`${runId}-${i}`,key:apiKey}));
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  let markers, mode, diag='n/a';
  if(location.protocol==='https:'&&typeof ReadableStream!=='undefined'){
   // HTTP/2 "last-byte sync": open 30 streams on ONE connection and send their headers, but withhold every body.
   // Then release all 30 bodies in a single synchronous loop. Browser dispatch jitter no longer matters because the
   // server stamps each request when it is COMPLETE (headers + body).
   mode='HTTP/2 last-byte sync';
   await api('/api/c02/warmup');                                   // establish the h2 connection first
   const enc=new TextEncoder(), ctrls=[]; const d0=performance.now();
   const inflight=bodies.map(()=>{let c;const st=new ReadableStream({start(x){c=x}});ctrls.push(c);
     return fetch('/api/c02/arrival',{method:'POST',headers:{'Content-Type':'application/json','X-API-Key':apiKey},body:st,duplex:'half'})});
   const d1=performance.now();
   await sleep(300);                                               // let all 30 request headers reach the server
   const d2=performance.now();
   ctrls.forEach((c,i)=>{c.enqueue(enc.encode(bodies[i]));c.close()});   // release all 30 bodies at once
   const d3=performance.now(); diag=`create ${(d1-d0).toFixed(1)} ms / release ${(d3-d2).toFixed(1)} ms`;
   markers=await Promise.all(inflight.map(async p=>{const r=await p;if(!r.ok)throw Error((await r.json().catch(()=>({}))).detail||r.statusText);return r.json()}));
  }else{
   // Plain HTTP/1.1 fallback: shard across 5 loopback hostnames (own 6-connection pool each) and fire in one loop.
   mode='HTTP/1.1 sharded';
   const local=['localhost','127.0.0.1'].includes(location.hostname)||location.hostname.endsWith('.localhost');
   const bases=local?[1,2,3,4,5].map(n=>`${location.protocol}//c${n}.localhost:${location.port||80}`):[''];
   const per=Math.ceil(30/bases.length);
   await Promise.all(bases.flatMap(base=>Array.from({length:per},()=>fetch(`${base}/api/c02/warmup`,{mode:base?'cors':'same-origin'}).then(r=>r.json()))));
   const reqs=bodies.map((b,i)=>{const base=bases[i%bases.length];return {url:`${base}/api/c02/arrival`,init:{method:'POST',mode:base?'cors':'same-origin',headers:{'Content-Type':'text/plain'},body:b}}});
   const inflight=reqs.map(o=>fetch(o.url,o.init));
   markers=await Promise.all(inflight.map(async p=>{const r=await p;if(!r.ok)throw Error((await r.json().catch(()=>({}))).detail||r.statusText);return r.json()}));
  }
  const measured=await api(`/api/c02/runs/${runId}`);
  output.textContent='Arrival markers received. Testing atomic action commits…';
  const actions=await Promise.all(Array.from({length:30},()=>api('/api/actions',{method:'POST',body:JSON.stringify({idempotency_key:sharedKey,action_type:'C02_DASHBOARD_TEST',payload:{run_id:runId}})})));
  const committed=actions.filter(x=>x.status==='committed').length;
  const duplicates=actions.filter(x=>x.duplicate===true||x.status==='duplicate_rejected').length;
  const duplicateCommits=Math.max(0,committed-1);
  const passed=markers.length===30&&measured.requests_received===30&&measured.within_20ms&&committed===1&&duplicates===29&&duplicateCommits===0;
  output.innerHTML=`<div class="c02result ${passed?'pass':'fail'}"><b>${passed?'PASS — ALL CHECKS PASSED':'FAIL — REQUIREMENTS NOT MET'}</b><div class="c02resultgrid"><span>Requests received<strong>${measured.requests_received}/30</strong></span><span>Server arrival spread<strong>${measured.server_arrival_spread_ms} ms</strong></span><span>Successful commits<strong>${committed}</strong></span><span>Duplicates rejected<strong>${duplicates}</strong></span><span>Duplicate commits<strong>${duplicateCommits}</strong></span><span>Within 20 ms<strong>${measured.within_20ms?'YES':'NO'}</strong></span><span>Protocol<strong>${measured.http_version==='2'?'HTTP/2':'HTTP/'+measured.http_version}</strong></span><span>Header-arrival spread<strong>${measured.header_arrival_spread_ms} ms</strong></span><span>Mode<strong>${mode}</strong></span><span>Browser loop (create / release)<strong>${diag}</strong></span></div>${(!passed&&mode!=='HTTP/2 last-byte sync')?'<p>For a reliable ≤ 20 ms window run the HTTP/2 server (run_https.bat) and open https://localhost:8443</p>':''}<small>Run ID: ${runId}</small></div>`;
  loadAudit();refresh();
 }catch(e){output.textContent='C02 test error: '+e.message+' — check the API key and backend CMD window.'}
 finally{button.disabled=false;button.textContent='RUN C02 CONCURRENCY TEST'}
};

$('runC07').onclick=async()=>{const out=$('c07Result'),b=$('runC07');b.disabled=true;b.textContent='RUNNING…';out.textContent='Triggering intentional exception and probe requests…';
 try{const d=await api('/api/c07/self-test',{method:'POST'});
  const rows=d.probes.map(p=>`<tr><td>${p.probe}</td><td>${p.status}</td><td><code>${p.error_id||'—'}</code></td><td>${p.generic_envelope?'yes':'NO'}</td><td>${p.leak_markers_in_response===0?'none':p.leak_markers_in_response}</td><td>${p.logged_in_backend_audit_log?'yes':'NO'}</td></tr>`).join('');
  out.innerHTML=`<div class="c02result ${d.pass?'pass':'fail'}"><b>${d.pass?'PASS — NO LEAKAGE, TRACES IN AUDIT LOG ONLY':'FAIL — REQUIREMENTS NOT MET'}</b><p class="hint">Full diagnostic trace stored in backend log only: <b>${d.full_trace_in_backend_log_only?'YES':'NO'}</b></p><div style="overflow:auto"><table class="c07table"><thead><tr><th>Probe</th><th>HTTP</th><th>Error ID</th><th>Generic body</th><th>Leak markers</th><th>In audit log</th></tr></thead><tbody>${rows}</tbody></table></div></div>`}
 catch(e){out.textContent='C07 test error: '+e.message}
 finally{b.disabled=false;b.textContent='RUN C07 ERROR-LEAKAGE TEST'}};
$('showRaw').onclick=async()=>{const out=$('c07Raw');const headers={};const k=localStorage.getItem('climateshield_api_key');if(k)headers['X-API-Key']=k;
 const r=await fetch('/api/c07/trigger-exception',{headers});const t=await r.text();out.innerHTML=`<pre>HTTP ${r.status}\nx-error-id: ${r.headers.get('x-error-id')}\nserver header: ${r.headers.get('server')||'(none)'}\n\n${t.replace(/[<>&]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;'}[c]))}</pre>`};

$('runC13').onclick=async()=>{const out=$('c13Result'),b=$('runC13');b.disabled=true;b.textContent='RUNNING…';out.textContent='Replaying perturbation attacks…';
 try{const d=await api('/api/c13/self-test',{method:'POST'});
  const rows=d.scenarios.map(s=>`<tr><td>${s.scenario}</td><td>${s.adversary_change}</td><td>${s.truth_category}</td><td>${s.before.score} ${s.before.category}</td><td>${s.after.score} ${s.after.category}</td><td>${s.before_evaded?(s.after_evaded?'still evades (residual)':'blocked'):'—'}</td></tr>`).join('');
  const w=d.sweep_in_budget,o=d.sweep_out_of_budget_residual,c=d.cost_of_defense;
  out.innerHTML=`<div class="c02result ${d.pass?'pass':'fail'}"><b>${d.pass?'PASS — IN-BUDGET EVASION BLOCKED':'FAIL — REQUIREMENTS NOT MET'}</b><div style="overflow:auto"><table class="c07table"><thead><tr><th>Scenario</th><th>Adversary change</th><th>Truth</th><th>Before</th><th>After</th><th>Outcome</th></tr></thead><tbody>${rows}</tbody></table></div><div class="c02resultgrid"><span>In-budget evaded before<strong>${w.before_evaded_cases}/${w.honest_cases_attacked} (${(w.before_evasion_rate*100).toFixed(1)}%)</strong></span><span>In-budget evaded after<strong>${w.after_evaded_cases}/${w.honest_cases_attacked} (${(w.after_evasion_rate*100).toFixed(1)}%)</strong></span><span>Out-of-budget evaded before<strong>${(o.before_evasion_rate*100).toFixed(1)}%</strong></span><span>Out-of-budget evaded after (residual)<strong>${(o.after_evasion_rate*100).toFixed(1)}%</strong></span><span>Readings raised (cost)<strong>${(c.raise_rate*100).toFixed(1)}%</strong></span><span>Probe scanner flagged at probe<strong>${d.probe_detector.scanning_attacker_flagged_at_probe}</strong></span></div><small>${c.note} Coarse grid in this quick run; run scripts/c13_adversarial_test.py for the full sweep.</small></div>`}
 catch(e){out.textContent='C13 test error: '+e.message}
 finally{b.disabled=false;b.textContent='RUN C13 EVASION TEST'}};

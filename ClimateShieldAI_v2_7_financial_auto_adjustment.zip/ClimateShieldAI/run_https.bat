@echo off
REM HTTP/2 server for the C02 test (<=20 ms arrival window). Open https://localhost:8443 and accept the self-signed cert warning once.
if not exist certs\cert.pem python scripts\make_cert.py
hypercorn app.main:app --config toml:hypercorn.toml --bind 127.0.0.1:8443 --certfile certs\cert.pem --keyfile certs\key.pem

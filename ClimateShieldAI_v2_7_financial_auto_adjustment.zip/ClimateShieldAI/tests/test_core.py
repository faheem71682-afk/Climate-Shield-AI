from app.core import canonical_hash,climate_rule_baseline

def test_hash_is_order_independent(): assert canonical_hash({'a':1,'b':2})==canonical_hash({'b':2,'a':1})
def test_climate_baseline_returns_bounded_score():
 r=climate_rule_baseline(100,30,70,5,'Karachi'); assert 0<=r['risk_score']<=100


# ---- C07: error & information-leakage defense ----
import json, re, os
from pathlib import Path

def _client(tmp_path, monkeypatch):
    monkeypatch.setenv('ERROR_AUDIT_LOG', str(tmp_path/'err.log'))
    monkeypatch.delenv('APP_API_KEY', raising=False)
    import importlib, app.errors, app.main
    importlib.reload(app.errors); importlib.reload(app.main)
    from fastapi.testclient import TestClient
    return TestClient(app.main.app, raise_server_exceptions=False), tmp_path/'err.log'

def test_c07_exception_is_generic_for_client_and_detailed_in_log(tmp_path, monkeypatch):
    c, log = _client(tmp_path, monkeypatch)
    r = c.get('/api/c07/trigger-exception')
    assert r.status_code == 500
    e = r.json()['error']; assert re.fullmatch(r'ERR-[0-9A-F]{12}', e['error_id'])
    for marker in ('Traceback', 'sqlalchemy', 'sqlite', 'RuntimeError', 'INTENTIONAL', '.py', 'site-packages'):
        assert marker.lower() not in r.text.lower()
    assert 'server' not in r.headers or 'uvicorn' not in r.headers['server'].lower()
    rec = json.loads(log.read_text().splitlines()[-1])
    assert rec['error_id'] == e['error_id'] and 'Traceback' in rec['traceback'] and 'INTENTIONAL C07 TEST' in rec['exception_message']

def test_c07_validation_404_405_do_not_echo_input(tmp_path, monkeypatch):
    c, log = _client(tmp_path, monkeypatch)
    for r in (c.post('/api/climate/predict', content='{bad', headers={'content-type': 'application/json'}),
              c.post('/api/climate/predict', json={'district': "x'; DROP TABLE a;--", 'rainfall_mm': 'abc'}),
              c.get('/nope'), c.delete('/api/health')):
        assert 'error_id' in r.json()['error'] and 'DROP TABLE' not in r.text and 'pydantic' not in r.text.lower()
    assert len(log.read_text().splitlines()) == 4


# ---- C13: adversarial model / logic evasion defense ----
import random
from app.core import climate_rule_baseline, climate_components
from app.defense import harden_climate, BoundaryProbeDetector, BUDGET, LEVELS

def _rank(c): return LEVELS.index(c)

def test_c13_components_match_baseline_score():
    rnd = random.Random(1)
    for _ in range(2000):
        x = (rnd.uniform(0, 1000), rnd.uniform(-20, 60), rnd.uniform(0, 100), rnd.uniform(0, 30))
        assert round(sum(climate_components(*x).values()), 1) == climate_rule_baseline(*x, 'K')['risk_score']

def test_c13_blind_spot_exists_in_baseline_and_is_closed_by_defense():
    honest, attack = (150, 32, 78, 7), (150, 32, 74, 7)          # humidity shaved by 4 points
    assert climate_rule_baseline(*honest, 'K')['risk_category'] == 'HIGH'
    assert climate_rule_baseline(*attack, 'K')['risk_category'] == 'MEDIUM'   # BEFORE: evaded
    r = harden_climate(*attack, 'K'); assert r['risk_category'] == 'HIGH' and 'NEAR_THRESHOLD_ESCALATED' in r['defense']['flags']  # AFTER

def test_c13_guarantee_in_budget_perturbation_never_lowers_category_fuzz():
    rnd = random.Random(13)
    for _ in range(20000):
        x = (rnd.uniform(0, 400), rnd.uniform(-20, 60), rnd.uniform(0, 100), rnd.uniform(0, 15))
        y = (x[0], max(x[1] - rnd.uniform(0, BUDGET['temperature_c']), -20), max(x[2] - rnd.uniform(0, BUDGET['humidity_pct']), 0), x[3])
        assert _rank(harden_climate(*y, 'K')['risk_category']) >= _rank(climate_rule_baseline(*x, 'K')['risk_category'])

def test_c13_hardening_never_downgrades_and_benign_low_is_untouched():
    rnd = random.Random(7)
    for _ in range(5000):
        x = (rnd.uniform(0, 1000), rnd.uniform(-20, 60), rnd.uniform(0, 100), rnd.uniform(0, 30))
        assert _rank(harden_climate(*x, 'K')['risk_category']) >= _rank(climate_rule_baseline(*x, 'K')['risk_category'])
    r = harden_climate(10, 25, 50, 1, 'K'); assert r['risk_category'] == 'LOW' and r['defense']['flags'] == []

def test_c13_critical_evidence_floor_and_humidity_clamp():
    r = harden_climate(160, 25, 40, 8, 'K')                      # strong flood drivers, auxiliary inputs zeroed out
    assert r['defense']['raw_category'] == 'MEDIUM' and r['risk_category'] == 'HIGH' and 'HUMIDITY_RAIN_INCONSISTENT' in r['defense']['flags']

def test_c13_probe_detector_flags_scanner_not_retries():
    d = BoundaryProbeDetector()
    assert [d.observe('a', 65.3, (150, 32, h, 7), now=i) for i, h in enumerate(range(79, 70, -1))].index(True) == 5
    assert not any(d.observe('b', 65.3, (150, 32, 78, 7), now=i) for i in range(30))   # identical retries
    assert not any(d.observe('c', 5.0, (5, 22, 40 + i, .5), now=i) for i in range(30))  # varied but far from any cut-off
    e = BoundaryProbeDetector(max_keys=3)
    for k in range(10): e.observe(f'k{k}', 65.0, (k,), now=0)
    assert len(e._h) <= 3                                                               # bounded memory

def test_c13_endpoint_returns_hardened_category(tmp_path, monkeypatch):
    c, _ = _client(tmp_path, monkeypatch)
    r = c.post('/api/climate/predict', json={'district': 'Karachi', 'rainfall_mm': 150, 'temperature_c': 32, 'humidity_pct': 74, 'river_level_m': 7})
    assert r.status_code == 200 and r.json()['risk_category'] == 'HIGH' and r.json()['defense']['raw_category'] == 'MEDIUM'

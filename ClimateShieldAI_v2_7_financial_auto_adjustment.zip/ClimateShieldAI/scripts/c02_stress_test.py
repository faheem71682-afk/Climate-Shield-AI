"""Network C02 verification. Start uvicorn first. Uses one request ID per arrival and one shared action key."""
import asyncio, os, time, uuid, httpx
BASE=os.getenv('BASE_URL','http://127.0.0.1:8000'); KEY=os.getenv('APP_API_KEY','')
HEADERS={'X-API-Key':KEY} if KEY else {}
async def main():
    run_id=str(uuid.uuid4()); shared='c02-'+str(uuid.uuid4())
    async with httpx.AsyncClient(base_url=BASE,headers=HEADERS,timeout=30) as c:
        # First, create 30 independent ingress markers and measure their server-observed spread.
        async def mark(i): return await c.post('/api/c02/arrival',json={'run_id':run_id,'request_id':f'{run_id}-{i}'})
        # Warm the connection pool so TCP handshakes don't land inside the timed burst.
        await asyncio.gather(*(c.get('/api/c02/warmup') for _ in range(30)))
        t0=time.perf_counter_ns(); marks=await asyncio.gather(*(mark(i) for i in range(30))); client_launch_ms=(time.perf_counter_ns()-t0)/1e6
        if any(r.status_code!=200 for r in marks): raise RuntimeError([r.text for r in marks if r.status_code!=200])
        measured=(await c.get(f'/api/c02/runs/{run_id}')).json()
        # Then hit the actual atomic operation concurrently with the same idempotency key.
        async def action(i): return await c.post('/api/actions',json={'idempotency_key':shared,'action_type':'C02_NETWORK_TEST','payload':{'run_id':run_id}})
        responses=await asyncio.gather(*(action(i) for i in range(30)))
        if any(r.status_code not in (200,409) for r in responses): raise RuntimeError([r.text for r in responses if r.status_code not in (200,409)])
        body=[r.json() for r in responses]; commits=sum(x.get('status')=='committed' for x in body); dupes=sum(x.get('duplicate') is True for x in body)
        passed=measured['within_20ms'] and commits==1 and dupes==29
        print({'requests':30,'client_batch_elapsed_ms':round(client_launch_ms,3),'server_arrival_spread_ms':measured['server_arrival_spread_ms'],'within_20ms':measured['within_20ms'],'committed':commits,'duplicates_rejected':dupes,'duplicate_commits':max(0,commits-1),'PASS':passed})
        raise SystemExit(0 if passed else 1)
if __name__=='__main__': asyncio.run(main())

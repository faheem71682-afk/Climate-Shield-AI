"""Create a self-signed localhost certificate (certs/cert.pem + certs/key.pem) for HTTP/2.  Run once:  python scripts/make_cert.py"""
import datetime, ipaddress, pathlib
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
out=pathlib.Path(__file__).resolve().parent.parent/'certs'; out.mkdir(exist_ok=True)
key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'localhost')]); now=datetime.datetime.now(datetime.timezone.utc)
cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number())
      .not_valid_before(now-datetime.timedelta(days=1)).not_valid_after(now+datetime.timedelta(days=825))
      .add_extension(x509.SubjectAlternativeName([x509.DNSName('localhost'),x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]),critical=False)
      .sign(key,hashes.SHA256()))
(out/'key.pem').write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.TraditionalOpenSSL,serialization.NoEncryption()))
(out/'cert.pem').write_bytes(cert.public_bytes(serialization.Encoding.PEM))
print('Created',out/'cert.pem','and',out/'key.pem')

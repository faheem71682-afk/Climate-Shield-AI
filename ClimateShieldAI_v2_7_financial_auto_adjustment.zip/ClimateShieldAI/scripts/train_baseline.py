"""Train an exploratory rainfall/heat classification model from downloaded NASA POWER data.
Labels are heuristic proxies, not verified disaster outcomes; do not call this an official forecast.
"""
import argparse, json
from pathlib import Path
import pandas as pd, joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

def main():
 p=argparse.ArgumentParser(); p.add_argument('--input',default='data/raw/nasa_power_pakistan.csv'); p.add_argument('--model',default='models/climate_risk_rf.joblib'); a=p.parse_args()
 df=pd.read_csv(a.input).dropna(subset=['rainfall_mm','temperature_c','humidity_pct'])
 # Transparent proxy label: severe rainfall OR extreme heat. Requires domain validation for real use.
 df['risk_label']=((df.rainfall_mm>=50)|(df.temperature_c>=40)).astype(int)
 X=df[['rainfall_mm','temperature_c','humidity_pct']]; y=df.risk_label
 if y.nunique()<2: raise SystemExit('Need both proxy classes; fetch a wider date range.')
 Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
 model=RandomForestClassifier(n_estimators=300,max_depth=12,class_weight='balanced',random_state=42,n_jobs=-1); model.fit(Xtr,ytr)
 Path(a.model).parent.mkdir(parents=True,exist_ok=True); joblib.dump({'model':model,'features':list(X.columns),'label_definition':'rainfall_mm>=50 OR temperature_c>=40; heuristic proxy, not observed disaster label'},a.model)
 print(classification_report(yte,model.predict(Xte))); print('Saved',a.model)
if __name__=='__main__': main()

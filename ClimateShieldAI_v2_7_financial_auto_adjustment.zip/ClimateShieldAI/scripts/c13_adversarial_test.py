"""C13 verification: adversarial perturbation of non-critical features, BEFORE vs AFTER the defensive validation boundary.
Run from the project folder (no server, database or third-party packages needed):  python scripts/c13_adversarial_test.py"""
import sys, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.c13_eval import evaluate

r = evaluate()
print('C13 - adversarial evasion of non-critical features\n')
print(f"Perturbation budget (aux features): humidity -{r['budget']['humidity_pct']} pts, temperature -{r['budget']['temperature_c']} C  (max score swing {r['near_band_points']} pts)\n")
print(f"{'Scenario':<54}{'Truth':<8}{'BEFORE':<18}{'AFTER':<18}{'Result'}")
for s in r['scenarios']:
    b, a = s['before'], s['after']
    res = ('EVADED -> BLOCKED' if s['before_evaded'] and not s['after_evaded'] else 'EVADED -> STILL EVADES (residual)' if s['after_evaded']
           else 'no evasion (control)' if not s['before_evaded'] else '?')
    print(f"{s['scenario']:<54}{s['truth_category']:<8}{b['score']:>5} {b['category']:<11}{a['score']:>5} {a['category']:<11}{res}")
    if a['flags']: print(f"{'':<54}flags: {', '.join(a['flags'])}")
for title, k in (('Automated attacker, IN budget (every honest MEDIUM/HIGH case, every perturbation combo)', 'sweep_in_budget'),
                 ('Automated attacker, OUT of budget (humidity -40, temperature -10) - residual risk', 'sweep_out_of_budget_residual')):
    s = r[k]; print(f"\n{title}\n  honest cases {s['honest_cases_attacked']}, attempts {s['attack_attempts']}\n"
                    f"  evaded BEFORE: {s['before_evaded_cases']} ({s['before_evasion_rate']:.1%})   evaded AFTER: {s['after_evaded_cases']} ({s['after_evasion_rate']:.1%})")
c = r['cost_of_defense']; print(f"\nCost: category raised on {c['category_raised']}/{c['readings_checked']} grid readings ({c['raise_rate']:.1%}). {c['note']}")
print('Probe detector:', json.dumps(r['probe_detector']))
print()
for k, v in r['checks'].items(): print(f"[{'PASS' if v else 'FAIL'}] {k}")
print('\nC13 RESULT:', 'PASS' if r['pass'] else 'FAIL'); sys.exit(0 if r['pass'] else 1)

"""C07 verification: trigger an intentional exception against a RUNNING server and prove that
(1) the client receives only a generic error ID, and (2) the full trace exists only in the backend audit log.
Run from the project folder with the API up:  python scripts/c07_error_leak_test.py
Env: C07_BASE (default http://127.0.0.1:8000), APP_API_KEY, ERROR_AUDIT_LOG (default logs/error_audit.log)."""
import os, sys, json, re, httpx
BASE=os.getenv('C07_BASE','http://127.0.0.1:8000'); KEY=os.getenv('APP_API_KEY','')
LOG=os.getenv('ERROR_AUDIT_LOG','logs/error_audit.log')
H={'X-API-Key':KEY} if KEY else {}
LEAK=['Traceback','File "','site-packages','sqlalchemy','sqlite','fastapi','starlette','uvicorn','hypercorn','python','RuntimeError','INTENTIONAL','.py','postgres','psycopg']
def log_record(eid):
    if not os.path.exists(LOG): return None
    for line in reversed(open(LOG,encoding='utf-8').read().splitlines()):
        if eid in line: return json.loads(line)
ok=True
def check(name,cond,extra=''):
    global ok; ok&=bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name} {extra}")
c=httpx.Client(base_url=BASE,verify=False,timeout=15)
probes=[('intentional exception','GET','/api/c07/trigger-exception',None),
        ('unknown route','GET','/api/nope/../../etc/passwd',None),
        ('wrong method','DELETE','/api/health',None),
        ('malformed JSON','POST','/api/climate/predict','{bad'),
        ('schema violation / injection string','POST','/api/climate/predict','{"district":"x\'; DROP TABLE a;--","rainfall_mm":"abc"}')]
for name,m,p,b in probes:
    r=c.request(m,p,content=b,headers={**H,'content-type':'application/json'})
    print(f'\n--- {name}: HTTP {r.status_code}\n{r.text}')
    try: e=r.json()['error']
    except Exception: e=None
    check('generic envelope with error_id',bool(e and re.fullmatch(r'ERR-[0-9A-F]{12}',e.get('error_id',''))))
    hits=[x for x in LEAK if x.lower() in r.text.lower()]
    check('no leak markers in body',not hits,str(hits) if hits else '')
    check('no Server / X-Powered-By header','server' not in r.headers or 'uvicorn' not in r.headers['server'].lower() and 'hypercorn' not in r.headers['server'].lower())
    if e:
        rec=log_record(e['error_id']); check('error_id present in backend audit log',rec is not None)
        if name=='intentional exception' and rec:
            check('full traceback + exception message in audit log only','Traceback' in rec.get('traceback','') and 'INTENTIONAL C07 TEST' in rec.get('exception_message',''))
            print('\n--- backend audit log record (NOT sent to client) ---'); print(json.dumps({k:rec[k] for k in ('error_id','exception_type','exception_message')},indent=2)); print(rec['traceback'][-600:])
print('\nC07 RESULT:','PASS' if ok else 'FAIL'); sys.exit(0 if ok else 1)

"""Low-overhead C02 burst: opens 30 sockets, pre-builds every request, then writes all 30 in one tight loop.
Measures what the SERVER can ingest (httpx adds ~2 ms/request of client overhead, which is not server latency)."""
import asyncio, json, os, uuid, httpx
HOST,PORT=os.getenv('C02_HOST','127.0.0.1'),int(os.getenv('C02_PORT','8000')); KEY=os.getenv('APP_API_KEY','')
def build(run,i):
    b=json.dumps({'run_id':run,'request_id':f'{run}-{i}','key':KEY}).encode()
    return (f'POST /api/c02/arrival HTTP/1.1\r\nHost: {HOST}:{PORT}\r\nContent-Type: application/json\r\nContent-Length: {len(b)}\r\nConnection: close\r\n\r\n').encode()+b
async def main():
    run=str(uuid.uuid4())
    conns=await asyncio.gather(*(asyncio.open_connection(HOST,PORT) for _ in range(30)))   # connect first, outside the burst
    reqs=[build(run,i) for i in range(30)]
    for (r,w),q in zip(conns,reqs): w.write(q)                                              # synchronous burst
    await asyncio.gather(*(w.drain() for _,w in conns))
    resp=await asyncio.gather(*(r.read() for r,_ in conns))
    ok=sum(b' 200 ' in x.split(b'\r\n')[0] for x in resp)
    async with httpx.AsyncClient(base_url=f'http://{HOST}:{PORT}',headers={'X-API-Key':KEY} if KEY else {}) as c:
        m=(await c.get(f'/api/c02/runs/{run}')).json()
    print({'accepted':ok,**m}); raise SystemExit(0 if ok==30 and m['within_20ms'] else 1)
asyncio.run(main())

"""Fetch daily NASA POWER climate observations for Pakistan sample grid points."""
import argparse, requests, pandas as pd
from pathlib import Path
POINTS={'Karachi':(24.8607,67.0011),'Lahore':(31.5204,74.3587),'Islamabad':(33.6844,73.0479),'Peshawar':(34.0151,71.5249),'Quetta':(30.1798,66.9750),'Multan':(30.1575,71.5249),'Gilgit':(35.9208,74.3080),'Hyderabad':(25.3960,68.3578),'Sukkur':(27.7052,68.8574),'Muzaffarabad':(34.3700,73.4711)}
PARAMS='PRECTOTCORR,T2M,RH2M'
def main():
 p=argparse.ArgumentParser(); p.add_argument('--start',default='20190101'); p.add_argument('--end',default='20251231'); p.add_argument('--out',default='data/raw/nasa_power_pakistan.csv'); a=p.parse_args(); rows=[]
 for district,(lat,lon) in POINTS.items():
  url='https://power.larc.nasa.gov/api/temporal/daily/point'
  q={'parameters':PARAMS,'community':'AG','longitude':lon,'latitude':lat,'start':a.start,'end':a.end,'format':'JSON'}
  r=requests.get(url,params=q,timeout=90); r.raise_for_status(); payload=r.json()['properties']['parameter']
  for date in payload['T2M']:
   rows.append({'date':date,'district':district,'latitude':lat,'longitude':lon,'rainfall_mm':payload['PRECTOTCORR'].get(date),'temperature_c':payload['T2M'].get(date),'humidity_pct':payload['RH2M'].get(date)})
  print('Fetched',district)
 Path(a.out).parent.mkdir(parents=True,exist_ok=True); pd.DataFrame(rows).to_csv(a.out,index=False); print('Saved',len(rows),'rows to',a.out)
if __name__=='__main__': main()

"""C07 - Hardened error & information-leakage defense.

Client-facing: every failure returns the same generic JSON envelope
    {"error": {"code": "...", "message": "<generic>", "error_id": "ERR-XXXXXXXXXXXX"}}
Backend-only: the full diagnostic trace (exception type/message, traceback, request context)
is written as one JSON line to logs/error_audit.log (override with ERROR_AUDIT_LOG).
The log is never served over HTTP; operators correlate a client's error_id with the log.
"""
import os, json, uuid, time, traceback, logging, platform, sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LOG_PATH = Path(os.getenv('ERROR_AUDIT_LOG', ROOT / 'logs' / 'error_audit.log'))

GENERIC = {
    400: ('BAD_REQUEST', 'The request could not be processed.'),
    401: ('UNAUTHORIZED', 'Authentication is required or invalid.'),
    403: ('FORBIDDEN', 'You do not have access to this resource.'),
    404: ('NOT_FOUND', 'The requested resource was not found.'),
    405: ('METHOD_NOT_ALLOWED', 'This method is not allowed for the resource.'),
    409: ('CONFLICT', 'The request conflicts with the current state of the resource.'),
    413: ('PAYLOAD_TOO_LARGE', 'The request is too large.'),
    422: ('INVALID_INPUT', 'The submitted data is invalid.'),
    429: ('RATE_LIMITED', 'Too many requests. Please retry later.'),
    503: ('UNAVAILABLE', 'The service is temporarily unavailable.'),
}
SERVER_ERROR = ('INTERNAL_ERROR', 'An internal error occurred. Quote the error ID when contacting support.')

_audit = logging.getLogger('climateshield.error_audit')


def _setup_logger():
    if _audit.handlers:
        return
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    h = RotatingFileHandler(LOG_PATH, maxBytes=5_000_000, backupCount=5, encoding='utf-8')
    h.setFormatter(logging.Formatter('%(message)s'))
    _audit.addHandler(h)
    _audit.setLevel(logging.INFO)
    _audit.propagate = False          # keep traces out of the console/uvicorn access log too


def new_error_id() -> str:
    return 'ERR-' + uuid.uuid4().hex[:12].upper()


def _client_ip(scope) -> str:
    c = scope.get('client')
    return c[0] if c else ''


def audit_error(error_id, *, status, scope, exc=None, detail=None, kind='exception'):
    """Write the comprehensive diagnostic record. Backend log only."""
    _setup_logger()
    rec = {
        'ts': time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime()) + 'Z',
        'error_id': error_id, 'kind': kind, 'status': status,
        'method': scope.get('method'), 'path': scope.get('path'),
        'query': (scope.get('query_string') or b'').decode('latin-1')[:500],
        'client_ip': _client_ip(scope),
        'user_agent': next((v.decode('latin-1')[:200] for k, v in scope.get('headers', []) if k == b'user-agent'), ''),
        'http_version': scope.get('http_version'),
        'runtime': {'python': sys.version.split()[0], 'platform': platform.platform()},
    }
    if exc is not None:
        rec['exception_type'] = f'{type(exc).__module__}.{type(exc).__qualname__}'
        rec['exception_message'] = str(exc)[:2000]
        rec['traceback'] = ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))[-8000:]
    if detail is not None:
        rec['detail'] = detail if isinstance(detail, (str, int, float, list, dict)) else repr(detail)
    _audit.info(json.dumps(rec, default=str))


def envelope(status: int, error_id: str) -> dict:
    code, msg = GENERIC.get(status, SERVER_ERROR) if status < 500 or status in GENERIC else SERVER_ERROR
    return {'error': {'code': code, 'message': msg, 'error_id': error_id}}


# Headers that identify server software / framework.
_STRIP = {b'server', b'x-powered-by', b'via'}
_SEC_HEADERS = [
    (b'x-content-type-options', b'nosniff'),
    (b'cache-control', b'no-store'),
    (b'referrer-policy', b'no-referrer'),
]


class HardenedErrorMiddleware:
    """Outermost pure-ASGI layer: catches anything raised anywhere below it (including other
    middleware), strips server-identifying headers, and guarantees a generic body."""
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            return await self.app(scope, receive, send)
        started = False

        async def send_wrap(message):
            nonlocal started
            if message['type'] == 'http.response.start':
                started = True
                hdrs = [(k, v) for k, v in message.get('headers', []) if k.lower() not in _STRIP]
                have = {k.lower() for k, _ in hdrs}
                if not scope['path'].startswith('/static'):
                    hdrs += [h for h in _SEC_HEADERS if h[0] not in have]
                else:
                    hdrs += [h for h in _SEC_HEADERS[:1] if h[0] not in have]
                message = {**message, 'headers': hdrs}
            await send(message)

        try:
            await self.app(scope, receive, send_wrap)
        except Exception as exc:                       # noqa: BLE001 - last line of defense
            if scope.get('c07_logged'):                 # Starlette re-raises after its 500 handler already logged it
                return
            eid = new_error_id()
            audit_error(eid, status=500, scope=scope, exc=exc, kind='unhandled_exception')
            if started:
                return                                  # response already begun; nothing safe to add
            body = json.dumps(envelope(500, eid)).encode()
            await send_wrap({'type': 'http.response.start', 'status': 500,
                             'headers': [(b'content-type', b'application/json'),
                                         (b'content-length', str(len(body)).encode()),
                                         (b'x-error-id', eid.encode())]})
            await send_wrap({'type': 'http.response.body', 'body': body})


def install(app):
    """Register generic handlers for every error class FastAPI/Starlette would otherwise detail."""
    from fastapi import Request
    from fastapi.exceptions import RequestValidationError
    from fastapi.responses import JSONResponse
    from starlette.exceptions import HTTPException as StarletteHTTPException

    @app.exception_handler(StarletteHTTPException)
    async def http_exc(request: Request, exc: StarletteHTTPException):
        eid = new_error_id()
        audit_error(eid, status=exc.status_code, scope=request.scope, detail=exc.detail, kind='http_exception')
        return JSONResponse(envelope(exc.status_code, eid), status_code=exc.status_code,
                            headers={'x-error-id': eid, **(dict(exc.headers) if exc.headers else {})})

    @app.exception_handler(RequestValidationError)
    async def validation_exc(request: Request, exc: RequestValidationError):
        eid = new_error_id()
        # Pydantic details echo submitted input and reveal schema/regex: log them, never return them.
        audit_error(eid, status=422, scope=request.scope, kind='validation_error',
                    detail=[{'loc': e.get('loc'), 'type': e.get('type'), 'msg': e.get('msg')} for e in exc.errors()])
        return JSONResponse(envelope(422, eid), status_code=422, headers={'x-error-id': eid})

    @app.exception_handler(Exception)
    async def any_exc(request: Request, exc: Exception):
        eid = new_error_id()
        audit_error(eid, status=500, scope=request.scope, exc=exc, kind='unhandled_exception')
        request.scope['c07_logged'] = True
        return JSONResponse(envelope(500, eid), status_code=500, headers={'x-error-id': eid})

    app.add_middleware(HardenedErrorMiddleware)

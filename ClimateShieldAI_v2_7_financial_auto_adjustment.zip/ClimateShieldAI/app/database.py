import os
from pathlib import Path
from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, sessionmaker

class Base(DeclarativeBase): pass

DATABASE_URL=os.getenv('DATABASE_URL','sqlite:///./data/climateshield.db')
Path('data').mkdir(exist_ok=True)
connect_args={'check_same_thread':False,'timeout':30} if DATABASE_URL.startswith('sqlite') else {}
engine=create_engine(DATABASE_URL,connect_args=connect_args,pool_pre_ping=True)
if DATABASE_URL.startswith('sqlite'):
    @event.listens_for(engine,'connect')
    def sqlite_pragmas(dbapi_connection, _):
        cur=dbapi_connection.cursor(); cur.execute('PRAGMA journal_mode=WAL'); cur.execute('PRAGMA busy_timeout=30000'); cur.execute('PRAGMA foreign_keys=ON'); cur.close()
SessionLocal=sessionmaker(bind=engine,expire_on_commit=False)

"""C13 - Adversarial model / logic evasion defense (model & heuristic defense).

BLIND SPOT (see docs/C13_ADVERSARIAL_DEFENSE.md): the baseline is additive with hard cut-offs (MEDIUM >= 35, HIGH >= 65) and
treats humidity/temperature as "free" auxiliary inputs.  An adversary who leaves the critical flood drivers (rainfall, river
level) untouched and shaves a few points off humidity/temperature slides a true HIGH under the 65 cut-off (e.g. humidity 78 -> 74
turns 66.0/HIGH into 64.8/MEDIUM).  Every individual value is in range, so schema validation never fires.

DEFENSIVE VALIDATION BOUNDARY (fail-safe: it can only ever RAISE a category, never lower one):
  1. Physical-consistency clamp     - heavy rain with implausibly dry air gets the humidity raised to a plausible floor.
  2. Perturbation-stability margin  - the category is the worst case over a bounded perturbation budget of the auxiliary
                                       features; if the category would flip inside that budget, the higher one is returned.
  3. Critical-evidence floor        - when rainfall + river alone are strongly elevated, HIGH cannot depend on auxiliary inputs.
  4. Boundary-probing detector      - flags a client that scans many distinct near-threshold inputs to map the cut-off.

Guarantee (property-tested): for ANY honest reading x and ANY submission x' that differs from x only by lowering humidity by
<= BUDGET['humidity_pct'] and temperature by <= BUDGET['temperature_c'], hardened_category(x') >= baseline_category(x).
Pure Python, no third-party imports, so it can be verified without the web stack.
"""
import threading, time
from collections import deque
from .core import climate_rule_baseline, climate_components

LEVELS = ('LOW', 'MEDIUM', 'HIGH')
THRESHOLDS = {'MEDIUM': 35.0, 'HIGH': 65.0}
BUDGET = {'humidity_pct': 10.0, 'temperature_c': 3.0}      # tolerated manipulation / sensor-noise envelope of auxiliary inputs
CRITICAL_HIGH_FLOOR = 55.0                                  # rainfall+river points (max 75) that force HIGH on their own
HUMIDITY_FLOORS = ((100.0, 70.0), (50.0, 60.0))             # (rain >= mm, humidity floor %), strongest rule first
NEAR_BAND = 15 * BUDGET['humidity_pct'] / 50 + 10 * BUDGET['temperature_c'] / 25   # max score swing inside the budget = 4.2


def _score(rain, temp, hum, river):
    return round(sum(climate_components(rain, temp, hum, river).values()), 1)


def _category(score):
    return 'HIGH' if score >= THRESHOLDS['HIGH'] else 'MEDIUM' if score >= THRESHOLDS['MEDIUM'] else 'LOW'


def _max_level(a, b):
    return a if LEVELS.index(a) >= LEVELS.index(b) else b


def harden_climate(rainfall_mm, temperature_c, humidity_pct, river_level_m, district):
    raw = climate_rule_baseline(rainfall_mm, temperature_c, humidity_pct, river_level_m, district)   # legacy "before" result
    flags = []
    eff_h = humidity_pct
    for rain_at, floor in HUMIDITY_FLOORS:                                    # 1. physical-consistency clamp
        if rainfall_mm >= rain_at:
            if humidity_pct < floor:
                eff_h = floor; flags.append('HUMIDITY_RAIN_INCONSISTENT')
            break
    parts = climate_components(rainfall_mm, temperature_c, eff_h, river_level_m)
    nominal = round(sum(parts.values()), 1)
    upper = _score(rainfall_mm, min(temperature_c + BUDGET['temperature_c'], 60), min(eff_h + BUDGET['humidity_pct'], 100), river_level_m)
    category = _category(nominal)
    worst_case = _category(upper)                                             # 2. perturbation-stability margin
    if worst_case != category and _max_level(worst_case, category) == worst_case:
        category = worst_case; flags.append('NEAR_THRESHOLD_ESCALATED')
    if parts['rainfall'] + parts['river'] >= CRITICAL_HIGH_FLOOR and category != 'HIGH':   # 3. critical-evidence floor
        category = 'HIGH'; flags.append('CRITICAL_EVIDENCE_FLOOR')
    if not flags and min(abs(nominal - t) for t in THRESHOLDS.values()) <= NEAR_BAND:
        flags.append('NEAR_THRESHOLD')
    return {'district': district, 'risk_score': nominal, 'risk_category': category, 'model_type': 'rule_baseline_hardened',
            'model_note': 'Baseline only, with C13 adversarial-robustness boundary; replace with a trained and validated model before operational use.',
            'defense': {'raw_score': raw['risk_score'], 'raw_category': raw['risk_category'], 'effective_humidity_pct': eff_h,
                        'worst_case_score': upper, 'flags': flags, 'review_required': bool(flags),
                        'escalated': category != raw['risk_category'] and LEVELS.index(category) > LEVELS.index(raw['risk_category'])}}


class BoundaryProbeDetector:
    """4. Flags a client that submits >= min_distinct DIFFERENT near-threshold readings inside a time window: the signature of
    an adversary binary-searching the cut-off.  Identical retries count once.  In-memory, per process, bounded (max_keys/max_events)
    so it cannot itself be used for memory exhaustion.  It flags; it does not block (rate limiting belongs at the gateway)."""
    def __init__(self, window_s=300.0, min_distinct=6, max_keys=1024, max_events=64):
        self.window_s, self.min_distinct, self.max_keys, self.max_events = window_s, min_distinct, max_keys, max_events
        self._h, self._lock = {}, threading.Lock()

    def observe(self, key, score, features, now=None):
        if min(abs(score - t) for t in THRESHOLDS.values()) > NEAR_BAND:
            return False
        now = time.monotonic() if now is None else now
        with self._lock:
            dq = self._h.pop(key, None) or deque(maxlen=self.max_events)
            while dq and now - dq[0][0] > self.window_s:
                dq.popleft()
            dq.append((now, tuple(features)))
            self._h[key] = dq
            while len(self._h) > self.max_keys:
                self._h.pop(next(iter(self._h)))
            return len({f for _, f in dq}) >= self.min_distinct


PROBES = BoundaryProbeDetector()

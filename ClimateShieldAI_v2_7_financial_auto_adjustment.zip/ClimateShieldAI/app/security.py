import os, hmac
from fastapi import Header, HTTPException

def _check(x_api_key):
    expected=os.getenv('APP_API_KEY')
    if not expected:
        if os.getenv('APP_ENV','development').lower()=='production':
            raise HTTPException(503,'APP_API_KEY must be configured in production')
        return 'local-development'
    if not x_api_key or not hmac.compare_digest(x_api_key,expected):
        raise HTTPException(401,'Missing or invalid API key')
    return 'api-key-user'

def require_api_key(x_api_key: str|None=Header(default=None)):
    return _check(x_api_key)

async def require_api_key_fast(x_api_key: str|None=Header(default=None)):
    # async variant: runs directly on the event loop (no thread-pool hop) for latency-critical endpoints
    return _check(x_api_key)

def api_key_ok(key)->bool:
    """Non-raising key check for the raw-ASGI C02 fast path (same rules as _check)."""
    try: _check(key); return True
    except HTTPException: return False

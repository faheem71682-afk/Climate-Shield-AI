import hashlib,json

def canonical_hash(payload:dict)->str:
    raw=json.dumps(payload,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
    return hashlib.sha256(raw).hexdigest()

def climate_rule_baseline(rainfall_mm,temperature_c,humidity_pct,river_level_m,district):
    score=min(rainfall_mm/200,1)*45+min(river_level_m/10,1)*30+min(max(humidity_pct-50,0)/50,1)*15+min(max(temperature_c-25,0)/25,1)*10
    score=round(score,1); category='HIGH' if score>=65 else 'MEDIUM' if score>=35 else 'LOW'
    return {'district':district,'risk_score':score,'risk_category':category,'model_type':'rule_baseline','model_note':'Baseline only; replace with a trained and validated model before operational use.'}

def climate_components(rainfall_mm,temperature_c,humidity_pct,river_level_m):
    """Per-feature score contributions of the baseline (same expressions as climate_rule_baseline; a test pins them together).
    rainfall + river are the CRITICAL flood drivers (max 75 pts); humidity + temperature are AUXILIARY (max 25 pts)."""
    return {'rainfall':min(rainfall_mm/200,1)*45,'river':min(river_level_m/10,1)*30,
            'humidity':min(max(humidity_pct-50,0)/50,1)*15,'temperature':min(max(temperature_c-25,0)/25,1)*10}

def append_audit(db, Audit, event_type, summary, payload_hash):
    last=db.query(Audit).order_by(Audit.id.desc()).first()
    previous=last.event_hash if last else '0'*64
    chain_hash=canonical_hash({'event_type':event_type,'summary':summary,'payload_hash':payload_hash,'previous_hash':previous})
    db.add(Audit(event_type=event_type,event_summary=summary,event_hash=chain_hash,previous_hash=previous,payload_hash=payload_hash))

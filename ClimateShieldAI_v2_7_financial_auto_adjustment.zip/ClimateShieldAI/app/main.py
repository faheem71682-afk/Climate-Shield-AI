import os, time, uuid, asyncio, json
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, ConfigDict
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func
from .database import Base,engine,SessionLocal
from .models import Action,Share,Audit,Arrival,RiskAdjustedExposure
from .core import canonical_hash,climate_rule_baseline,append_audit
from .defense import harden_climate,PROBES   # C13: adversarial-robustness boundary around the climate model
from .security import require_api_key, require_api_key_fast, api_key_ok
from . import errors as c07

ROOT=Path(__file__).resolve().parent.parent
_PROD=os.getenv('APP_ENV','development').lower()=='production'
# C07: in production the interactive docs / OpenAPI schema are not exposed (they map every endpoint and model for an attacker).
app=FastAPI(title='ClimateShield AI',version='2.0.0',description='Secure climate intelligence, protected aggregate sharing and concurrency verification.',
            docs_url=None if _PROD else '/docs',redoc_url=None,openapi_url=None if _PROD else '/openapi.json')

def _install_h2_early_stamp():
    """Hypercorn parses every HTTP/2 frame of a burst in one tight loop and only then lets each request's app task run.
    Stamp at the protocol layer (the moment the frame is parsed) so the measurement does not include event-loop task
    scheduling. No-op on other servers (uvicorn/granian): the middleware falls back to its own stamps."""
    try:
        from hypercorn.protocol.http_stream import HTTPStream
        from hypercorn.protocol.events import Request as _Req, EndBody as _End
    except Exception: return
    if getattr(HTTPStream,'_c02_patched',False): return
    _orig=HTTPStream.handle
    async def handle(self,event):
        ns=time.perf_counter_ns()
        if isinstance(event,_Req):
            try: event.headers.append((b'x-c02-headers-ns',str(ns).encode()))
            except Exception: pass
        elif isinstance(event,_End):
            sc=getattr(self,'scope',None)
            if isinstance(sc,dict): sc['c02_complete_ns']=ns
        return await _orig(self,event)
    HTTPStream.handle=handle; HTTPStream._c02_patched=True
_install_h2_early_stamp()
C02_RUNS: dict[str, dict[str,tuple[int,int]]] = {}   # run_id -> {request_id: (headers_ns, complete_ns)}; in-memory, single process
_C02_PATHS={'/api/c02/arrival','/api/c02/warmup'}
def _c02_origin_ok(origin:str)->bool:
    # Only loopback origins (localhost, 127.0.0.1, *.localhost) may call the sharded C02 endpoints cross-origin.
    from urllib.parse import urlparse
    h=(urlparse(origin).hostname or '').lower()
    return h in ('localhost','127.0.0.1','::1') or h.endswith('.localhost')
class ArrivalStampMiddleware:
    """Pure-ASGI fast path. Stamps the monotonic arrival time the instant the app receives the request,
    BEFORE routing, auth, body parsing or any DB work. The two C02 endpoints are answered right here
    (no FastAPI routing, no Pydantic, no dependency injection) so per-request server time is sub-millisecond
    and queued requests drain quickly. Every other request is stamped and passed through untouched."""
    def __init__(self, app): self.app=app
    async def __call__(self, scope, receive, send):
        if scope['type']!='http': return await self.app(scope, receive, send)
        ns=time.perf_counter_ns(); scope['arrived_ns']=ns
        if scope['path'] not in _C02_PATHS: return await self.app(scope, receive, send)
        hdr={k.decode('latin-1').lower():v.decode('latin-1') for k,v in scope['headers']}
        origin=hdr.get('origin',''); cors=[]
        if origin and _c02_origin_ok(origin):
            cors=[(b'access-control-allow-origin',origin.encode()),(b'vary',b'Origin'),
                  (b'access-control-allow-headers',b'content-type, x-api-key'),(b'access-control-allow-methods',b'GET, POST, OPTIONS')]
        async def reply(status:int, obj:dict|None=None):
            body=b'' if status==204 else json.dumps(obj if obj is not None else {}).encode()
            await send({'type':'http.response.start','status':status,'headers':[(b'content-type',b'application/json'),(b'content-length',str(len(body)).encode()),*cors]})
            await send({'type':'http.response.body','body':body})
        method=scope['method']
        if method=='OPTIONS': return await reply(204)
        if scope['path']=='/api/c02/warmup':
            await asyncio.sleep(0.3)            # hold the socket open so the browser really opens parallel connections
            return await reply(200,{'warm':True})
        if method!='POST': return await reply(405,{'detail':'Method not allowed'})
        raw=b''
        while True:
            m=await receive()
            if m['type']=='http.disconnect': return
            raw+=m.get('body',b'')
            if not m.get('more_body'): break
        done_ns=scope.get('c02_complete_ns') or time.perf_counter_ns()   # request COMPLETE (headers + full body); protocol-layer stamp when available
        try: ns=int(hdr.get('x-c02-headers-ns') or ns)
        except ValueError: pass
        try:
            body=json.loads(raw); run_id=str(body['run_id'])[:80]; request_id=str(body['request_id'])[:80]
        except Exception: return await reply(422,{'detail':'Invalid arrival payload'})
        # key: X-API-Key header, or "key" in the body (lets the browser send a CORS "simple" request with no preflight)
        if not api_key_ok(hdr.get('x-api-key') or body.get('key')): return await reply(401,{'detail':'Missing or invalid API key'})
        run=C02_RUNS.setdefault(run_id,{})
        if request_id in run: return await reply(409,{'detail':'Duplicate request_id'})
        run[request_id]=(ns,done_ns)            # in-memory only: no DB write inside the timed window
        while len(C02_RUNS)>200: C02_RUNS.pop(next(iter(C02_RUNS)))
        return await reply(200,{'received':True})
app.add_middleware(ArrivalStampMiddleware)
c07.install(app)   # C07: must be registered AFTER the other middleware so it is the outermost layer
app.mount('/static',StaticFiles(directory=ROOT/'static'),name='static')
@app.on_event('startup')
def startup(): Base.metadata.create_all(bind=engine)
def db_session():
    db=SessionLocal()
    try: yield db
    finally: db.close()
@app.get('/')
def dashboard(): return FileResponse(ROOT/'static'/'index.html')
@app.get('/api/health')
def health(): return {'status':'online','product':'ClimateShield AI','database':engine.dialect.name,'modules':['climate','input-integrity','privacy-aggregates','audit-chain','c02-concurrency','c07-error-hardening','c13-adversarial-defense']}
class ClimateInput(BaseModel):
    model_config=ConfigDict(str_strip_whitespace=True,extra='forbid')
    district:str=Field(min_length=2,max_length=80,pattern=r'^[A-Za-z .\-]+$')
    rainfall_mm:float=Field(ge=0,le=1000,allow_inf_nan=False)
    temperature_c:float=Field(ge=-20,le=60,allow_inf_nan=False)
    humidity_pct:float=Field(ge=0,le=100,allow_inf_nan=False)
    river_level_m:float=Field(ge=0,le=30,allow_inf_nan=False)
@app.post('/api/climate/predict')
def predict(data:ClimateInput, request:Request, user:str=Depends(require_api_key), db=Depends(db_session)):
    # C13: the hardened model never returns a LOWER category than the raw baseline; see app/defense.py
    inp=data.model_dump(); result=harden_climate(**inp); h=canonical_hash(inp); d=result['defense']
    client=request.client.host if request.client else 'unknown'
    if PROBES.observe(client,result['risk_score'],(inp['rainfall_mm'],inp['temperature_c'],inp['humidity_pct'],inp['river_level_m'])):
        d['flags'].append('BOUNDARY_PROBING_SUSPECTED'); d['review_required']=True
    append_audit(db,Audit,'CLIMATE_BASELINE',f"Risk assessment for {data.district}",h)
    if d['flags'] and d['flags']!=['NEAR_THRESHOLD']:
        append_audit(db,Audit,'C13_DEFENSE_TRIGGERED',f"{','.join(d['flags'])}; raw {d['raw_category']} -> {result['risk_category']} ({data.district})",h)
    db.commit()
    return {**result,'input_hash':h,'geographical_scope':'Pakistan','warning':'Not an official warning. Trained model integration is pending.'}
class ShareInput(BaseModel):
    model_config=ConfigDict(str_strip_whitespace=True,extra='forbid')
    institution:str=Field(min_length=2,max_length=80,pattern=r'^[A-Za-z0-9 &.\-]+$')
    district:str=Field(min_length=2,max_length=80,pattern=r'^[A-Za-z .\-]+$')
    exposure_amount:float=Field(gt=0,le=1_000_000_000,allow_inf_nan=False)
@app.post('/api/privacy/share')
def share(data:ShareInput,user:str=Depends(require_api_key),db=Depends(db_session)):
    h=canonical_hash(data.model_dump()); row=Share(**data.model_dump(),data_hash=h); db.add(row)
    append_audit(db,Audit,'AGGREGATE_SHARE',f"Synthetic aggregate from {data.institution} for {data.district}",h); db.commit()
    return {'status':'recorded','share_id':row.id,'data_hash':h,'privacy_note':'This endpoint accepts aggregate values only; do not submit personal or account-level records.'}
class RiskAdjustInput(BaseModel):
    model_config=ConfigDict(str_strip_whitespace=True,extra='forbid')
    institution:str=Field(min_length=2,max_length=80,pattern=r'^[A-Za-z0-9 &.\\-]+$')
    district:str=Field(min_length=2,max_length=80,pattern=r'^[A-Za-z .\\-]+$')
    base_exposure:float=Field(gt=0,le=1_000_000_000,allow_inf_nan=False)
    risk_category:str=Field(pattern=r'^(LOW|MEDIUM|HIGH)$')

RISK_MULTIPLIERS={'LOW':1.0,'MEDIUM':1.5,'HIGH':2.0}

@app.post('/api/privacy/risk-adjust')
def risk_adjust_exposure(data:RiskAdjustInput,user:str=Depends(require_api_key),db=Depends(db_session)):
    multiplier=RISK_MULTIPLIERS[data.risk_category]
    adjusted=round(data.base_exposure*multiplier,2)
    payload={**data.model_dump(),'multiplier':multiplier,'adjusted_exposure':adjusted}
    h=canonical_hash(payload)
    row=db.query(RiskAdjustedExposure).filter_by(institution=data.institution,district=data.district).first()
    if row:
        row.base_exposure=data.base_exposure
        row.risk_category=data.risk_category
        row.multiplier=multiplier
        row.adjusted_exposure=adjusted
        row.data_hash=h
        row.updated_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc)
    else:
        row=RiskAdjustedExposure(institution=data.institution,district=data.district,
            base_exposure=data.base_exposure,risk_category=data.risk_category,
            multiplier=multiplier,adjusted_exposure=adjusted,data_hash=h)
        db.add(row)
    append_audit(db,Audit,'RISK_ADJUSTED_EXPOSURE',
        f"{data.risk_category} risk adjusted exposure for {data.institution} in {data.district}: PKR {adjusted}",h)
    db.commit()
    return {'status':'updated','institution':data.institution,'district':data.district,
        'risk_category':data.risk_category,'base_exposure':data.base_exposure,
        'multiplier':multiplier,'adjusted_exposure':adjusted,'data_hash':h}

@app.get('/api/privacy/summary')
def summary(db=Depends(db_session)):
    manual=db.query(Share.district,func.sum(Share.exposure_amount).label('amount'),
        func.count(Share.id).label('records')).group_by(Share.district).all()
    adjusted=db.query(RiskAdjustedExposure.district,func.sum(RiskAdjustedExposure.adjusted_exposure).label('amount'),
        func.count(RiskAdjustedExposure.id).label('records')).group_by(RiskAdjustedExposure.district).all()
    totals={}
    for r in manual:
        item=totals.setdefault(r.district,{'district':r.district,'manual_exposure':0.0,
            'risk_adjusted_exposure':0.0,'total_exposure':0.0,'records':0})
        item['manual_exposure']+=float(r.amount or 0); item['records']+=int(r.records or 0)
    for r in adjusted:
        item=totals.setdefault(r.district,{'district':r.district,'manual_exposure':0.0,
            'risk_adjusted_exposure':0.0,'total_exposure':0.0,'records':0})
        item['risk_adjusted_exposure']+=float(r.amount or 0); item['records']+=int(r.records or 0)
    for item in totals.values():
        item['total_exposure']=round(item['manual_exposure']+item['risk_adjusted_exposure'],2)
        item['manual_exposure']=round(item['manual_exposure'],2)
        item['risk_adjusted_exposure']=round(item['risk_adjusted_exposure'],2)
    return {'aggregates':sorted(totals.values(),key=lambda x:x['district'])}
@app.get('/api/audit')
def audit(db=Depends(db_session)):
    return [{'id':r.id,'event_type':r.event_type,'summary':r.event_summary,'event_hash':r.event_hash,'previous_hash':r.previous_hash,'created_at':r.created_at.isoformat()} for r in db.query(Audit).order_by(Audit.id.desc()).limit(30).all()]
@app.get('/api/audit/verify')
def verify_audit(db=Depends(db_session)):
    rows=db.query(Audit).order_by(Audit.id).all(); prev='0'*64
    for r in rows:
        expected=canonical_hash({'event_type':r.event_type,'summary':r.event_summary,'payload_hash':r.payload_hash,'previous_hash':r.previous_hash})
        if r.previous_hash!=prev: return {'valid':False,'failed_event_id':r.id,'reason':'previous_hash_mismatch'}
        if r.event_hash!=expected: return {'valid':False,'failed_event_id':r.id,'reason':'event_hash_mismatch'}
        prev=r.event_hash
    return {'valid':True,'events_verified':len(rows),'chain_head':prev}
class ActionInput(BaseModel):
    model_config=ConfigDict(extra='forbid')
    idempotency_key:str=Field(min_length=8,max_length=120,pattern=r'^[A-Za-z0-9._:-]+$')
    action_type:str=Field(default='DISASTER_FINANCE_ACTION',min_length=2,max_length=80)
    payload:dict=Field(default_factory=dict)
@app.post('/api/actions')
def create_action(data:ActionInput,user:str=Depends(require_api_key),db=Depends(db_session)):
    p_hash=canonical_hash({'action_type':data.action_type,'payload':data.payload})
    row=Action(scope=user,idempotency_key=data.idempotency_key,payload_hash=p_hash,action_type=data.action_type)
    try:
        db.add(row); db.flush()
        append_audit(db,Audit,'ACTION_COMMITTED',f"Action {data.action_type} committed",p_hash); db.commit()
        return {'status':'committed','action_id':row.id,'duplicate':False}
    except IntegrityError:
        db.rollback()
        existing=db.query(Action).filter_by(scope=user,idempotency_key=data.idempotency_key).first()
        if existing and existing.payload_hash!=p_hash:
            raise HTTPException(409,'Idempotency key was already used with a different payload')
        return {'status':'duplicate_rejected','duplicate':True}
@app.post('/api/stress-test')
def stress_test(user:str=Depends(require_api_key),db=Depends(db_session)):
    # Server-side core-function race test; the client script separately measures ingress spread.
    key='c02-'+str(uuid.uuid4()); payload=ActionInput(idempotency_key=key,action_type='C02_VERIFICATION')
    from concurrent.futures import ThreadPoolExecutor
    def worker(_):
        with SessionLocal() as s:
            r=Action(scope=user,idempotency_key=key,payload_hash=canonical_hash({'action_type':payload.action_type,'payload':{}}),action_type=payload.action_type)
            try:
                s.add(r); s.commit(); return 'committed'
            except IntegrityError: s.rollback(); return 'duplicate_rejected'
    with ThreadPoolExecutor(max_workers=30) as pool: outcomes=list(pool.map(worker,range(30)))
    commits=outcomes.count('committed'); duplicates=outcomes.count('duplicate_rejected')
    return {'requests':30,'committed_actions':commits,'duplicates_rejected':duplicates,'duplicate_commits':max(0,commits-1),'atomic_consistency_pass':commits==1 and duplicates==29}
@app.get('/api/c02/runs/{run_id}')
async def c02_run(run_id:str,request:Request,user:str=Depends(require_api_key_fast)):
    run=C02_RUNS.get(run_id)
    if not run: raise HTTPException(404,'Run not found')
    hs=[v[0] for v in run.values()]; cs=[v[1] for v in run.values()]
    header_spread=(max(hs)-min(hs))/1_000_000; spread=(max(cs)-min(cs))/1_000_000   # spread = request-complete spread
    return {'run_id':run_id,'requests_received':len(cs),'server_arrival_spread_ms':round(spread,3),'header_arrival_spread_ms':round(header_spread,3),
            'http_version':request.scope.get('http_version'),'within_20ms':len(cs)==30 and spread<=20}
@app.get('/api/stats')
def stats(db=Depends(db_session)):
    return {'committed_actions':db.query(Action).count(),'privacy_shares':db.query(Share).count(),'audit_events':db.query(Audit).count()}

# ---------------- C13: adversarial evasion verification ----------------
@app.post('/api/c13/self-test')
def c13_self_test(user:str=Depends(require_api_key)):
    """Replays perturbation attacks on non-critical features against the raw baseline (BEFORE) and the hardened model (AFTER).
    Pure in-process computation: no state is written. quick=True keeps the sweep coarse so the request returns fast."""
    from .c13_eval import evaluate
    return evaluate(quick=True)

# ---------------- C07: error & information-leakage verification ----------------
@app.get('/api/c07/trigger-exception')
def c07_trigger(user:str=Depends(require_api_key)):
    """Intentional application exception. The message deliberately contains the kind of detail an attacker wants
    (DB engine/URL, library path, framework versions). It must reach ONLY logs/error_audit.log, never the client."""
    import sqlalchemy, fastapi, sys
    raise RuntimeError(f"INTENTIONAL C07 TEST: db={engine.url.render_as_string(hide_password=True)} dialect={engine.dialect.name} "
                       f"sqlalchemy={sqlalchemy.__version__} fastapi={fastapi.__version__} python={sys.version.split()[0]} root={ROOT}")
_LEAK_MARKERS=('Traceback','File "','site-packages','sqlalchemy','sqlite','fastapi','starlette','uvicorn','hypercorn','python','RuntimeError','INTENTIONAL','.py')
@app.post('/api/c07/self-test')
async def c07_self_test(request:Request,user:str=Depends(require_api_key_fast)):
    """Fires the intentional exception plus several probe-style bad requests through this same app, then reports ONLY
    pass/fail booleans and error IDs (never trace content). Trace presence is checked by reading the backend log."""
    import httpx
    key=request.headers.get('x-api-key'); hdr={'x-api-key':key} if key else {}
    probes=[('trigger-exception','GET','/api/c07/trigger-exception',None),
            ('unknown-route','GET','/api/does-not-exist/../../etc/passwd',None),
            ('wrong-method','DELETE','/api/health',None),
            ('malformed-json','POST','/api/climate/predict','{bad json'),
            ('schema-violation','POST','/api/climate/predict','{"district":"Karachi\'; DROP TABLE x;--","rainfall_mm":"abc"}')]
    results=[]
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app,raise_app_exceptions=False),base_url='http://c07.internal') as c:
        for name,method,path,body in probes:
            r=await c.request(method,path,content=body,headers={**hdr,'content-type':'application/json'})
            txt=r.text; low=txt.lower()
            try: eid=r.json()['error']['error_id']
            except Exception: eid=None
            leaked=[m for m in _LEAK_MARKERS if m.lower() in low]+[h for h in ('server','x-powered-by') if h in r.headers]
            logged=False
            if eid:
                try: logged=eid in LOG_TAIL()
                except Exception: logged=False
            results.append({'probe':name,'status':r.status_code,'error_id':eid,'generic_envelope':eid is not None,'leak_markers_in_response':len(leaked),'logged_in_backend_audit_log':logged})
    trig=results[0]
    trace_in_log=False
    if trig['error_id']:
        rec=LOG_FIND(trig['error_id'])
        trace_in_log=bool(rec and 'traceback' in rec and 'INTENTIONAL C07 TEST' in rec.get('exception_message',''))
    passed=all(x['generic_envelope'] and x['leak_markers_in_response']==0 and x['logged_in_backend_audit_log'] for x in results) and trace_in_log and trig['status']==500
    return {'pass':passed,'full_trace_in_backend_log_only':trace_in_log,'probes':results}
def LOG_TAIL(n=200_000):
    p=c07.LOG_PATH
    with open(p,'rb') as f:
        f.seek(0,2); size=f.tell(); f.seek(max(0,size-n)); return f.read().decode('utf-8','replace')
def LOG_FIND(error_id):
    for line in reversed(LOG_TAIL().splitlines()):
        if error_id in line:
            try: return json.loads(line)
            except Exception: return None

"""C13 before/after evaluation. Pure Python; shared by scripts/c13_adversarial_test.py and POST /api/c13/self-test."""
from itertools import product
from .core import climate_rule_baseline
from .defense import harden_climate, BoundaryProbeDetector, BUDGET, LEVELS, NEAR_BAND

_K = ('rainfall_mm', 'temperature_c', 'humidity_pct', 'river_level_m')
def _before(x): r = climate_rule_baseline(*x, 'eval'); return r['risk_score'], r['risk_category']
def _after(x): r = harden_climate(*x, 'eval'); return r['risk_score'], r['risk_category'], r['defense']['flags']
def _lt(a, b): return LEVELS.index(a) < LEVELS.index(b)

# (name, what the adversary changes, honest reading, submitted reading) -- order: rain, temp, humidity, river
SCENARIOS = [
    ('Humidity shave on a flood-driven HIGH', 'humidity 78 -> 74 (4 pts)', (150, 32, 78, 7), (150, 32, 74, 7), True),
    ('Coordinated aux dilution, strong flood drivers', 'humidity 85 -> 40, temperature 32 -> 25', (160, 32, 85, 8), (160, 25, 40, 8), False),
    ('MEDIUM -> LOW at the 35 cut-off', 'humidity 60 -> 59 (1 pt)', (80, 30, 60, 4), (80, 30, 59, 4), True),
    ('Temperature + humidity shave just under 65', 'humidity 80 -> 72, temperature 36 -> 34', (140, 36, 80, 7.5), (140, 34, 72, 7.5), True),
    ('CONTROL: benign low-risk reading', 'none (submitted unchanged)', (10, 25, 50, 1), (10, 25, 50, 1), True),
    ('RESIDUAL: large out-of-budget shave, moderate rain', 'humidity 95 -> 45, temperature 38 -> 28', (95, 40, 95, 10), (95, 28, 45, 10), False),
]

def _clamp(x, dh, dt):
    r, t, h, v = x; return (r, max(t - dt, -20), max(h - dh, 0), v)

def _grid(quick=False):
    axes = (range(0, 401, 50), range(0, 13, 2), range(40, 101, 20), range(20, 51, 10)) if quick else \
           (range(0, 401, 25), range(0, 13), range(40, 101, 10), range(20, 51, 5))
    for r, v, h, t in product(*axes):
        yield (float(r), float(t), float(h), float(v))

def sweep(max_dh, max_dt, step_h=1, step_t=1, quick=False):
    honest = attempts = b_ev = a_ev = 0
    for x in _grid(quick):
        base_cat = _before(x)[1]
        if base_cat == 'LOW': continue
        honest += 1
        b_hit = a_hit = False
        for dh, dt in product(range(0, int(max_dh) + 1, step_h), range(0, int(max_dt) + 1, step_t)):
            y = _clamp(x, dh, dt); attempts += 1
            if _lt(_before(y)[1], base_cat): b_hit = True
            if _lt(_after(y)[1], base_cat): a_hit = True
        b_ev += b_hit; a_ev += a_hit
    return {'honest_cases_attacked': honest, 'attack_attempts': attempts, 'before_evaded_cases': b_ev, 'after_evaded_cases': a_ev,
            'before_evasion_rate': round(b_ev / honest, 4), 'after_evasion_rate': round(a_ev / honest, 4)}

def cost(quick=False):
    n = up = 0
    for x in _grid(quick):
        n += 1; up += _lt(_before(x)[1], _after(x)[1])
    return {'readings_checked': n, 'category_raised': up, 'raise_rate': round(up / n, 4),
            'note': 'Uniform grid, not a real-world distribution; every raise is fail-safe (more cautious), never a downgrade.'}

def probe_demo():
    d, out = BoundaryProbeDetector(), {}
    out['scanning_attacker_flagged_at_probe'] = next((i for i, h in enumerate(range(79, 70, -1), 1)
                                                      if d.observe('atk', 65.3, (150, 32, h, 7), now=i)), None)
    out['benign_retry_flagged'] = any(d.observe('retry', 65.3, (150, 32, 78, 7), now=i) for i in range(30))
    out['far_from_threshold_varied_flagged'] = any(d.observe('far', 5.0, (5, 22, 40 + i, 0.5), now=i) for i in range(30))
    return out

def evaluate(quick=False):
    rows = []
    for name, change, honest, sub, in_budget in SCENARIOS:
        hb, ha = _before(honest), _after(honest)
        sb, sa = _before(sub), _after(sub)
        rows.append({'scenario': name, 'adversary_change': change, 'in_budget': in_budget,
                     'truth_category': hb[1], 'before': {'score': sb[0], 'category': sb[1]},
                     'after': {'score': sa[0], 'category': sa[1], 'flags': sa[2]},
                     'before_evaded': _lt(sb[1], hb[1]), 'after_evaded': _lt(sa[1], hb[1])})
    out = {'budget': BUDGET, 'near_band_points': NEAR_BAND, 'scenarios': rows,
           'sweep_in_budget': sweep(BUDGET['humidity_pct'], BUDGET['temperature_c'], *((2, 1) if quick else (1, 1)), quick=quick),
           'sweep_out_of_budget_residual': sweep(40, 10, 5, 2, quick=quick), 'cost_of_defense': cost(quick), 'probe_detector': probe_demo()}
    p = out['probe_detector']; s = {r['scenario']: r for r in rows}
    checks = {
        'attacks_evade_baseline': all(r['before_evaded'] for r in rows if r['scenario'].split(':')[0] not in ('CONTROL', 'RESIDUAL')),
        'in_budget_attacks_blocked_after': all(not r['after_evaded'] for r in rows if r['in_budget']),
        'sweep_in_budget_zero_evasion_after': out['sweep_in_budget']['after_evaded_cases'] == 0,
        'control_not_escalated': s['CONTROL: benign low-risk reading']['after']['category'] == 'LOW' and not s['CONTROL: benign low-risk reading']['after']['flags'],
        'probe_detector_flags_scanner_only': p['scanning_attacker_flagged_at_probe'] is not None and not p['benign_retry_flagged'] and not p['far_from_threshold_varied_flagged'],
    }
    out['checks'] = checks; out['pass'] = all(checks.values())
    return out

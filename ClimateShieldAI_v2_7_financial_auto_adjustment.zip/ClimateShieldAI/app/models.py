from datetime import datetime, timezone
from sqlalchemy import String, Integer, Float, DateTime, Text, UniqueConstraint, Index
from sqlalchemy.orm import Mapped, mapped_column
from .database import Base

def now(): return datetime.now(timezone.utc)
class Action(Base):
    __tablename__='actions'
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    scope: Mapped[str]=mapped_column(String(120),nullable=False)
    idempotency_key: Mapped[str]=mapped_column(String(120),nullable=False)
    payload_hash: Mapped[str]=mapped_column(String(64),nullable=False)
    action_type: Mapped[str]=mapped_column(String(80),nullable=False)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,nullable=False)
    __table_args__=(UniqueConstraint('scope','idempotency_key',name='uq_action_scope_key'),)
class Share(Base):
    __tablename__='shares'
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    institution: Mapped[str]=mapped_column(String(80),nullable=False)
    district: Mapped[str]=mapped_column(String(80),nullable=False)
    exposure_amount: Mapped[float]=mapped_column(Float,nullable=False)
    data_hash: Mapped[str]=mapped_column(String(64),nullable=False)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,nullable=False)
class Audit(Base):
    __tablename__='audit'
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    event_type: Mapped[str]=mapped_column(String(60),nullable=False)
    event_summary: Mapped[str]=mapped_column(Text,nullable=False)
    event_hash: Mapped[str]=mapped_column(String(64),nullable=False)
    previous_hash: Mapped[str]=mapped_column(String(64),nullable=False)
    payload_hash: Mapped[str]=mapped_column(String(64),nullable=False)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,nullable=False)
class Arrival(Base):
    __tablename__='c02_arrivals'
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    run_id: Mapped[str]=mapped_column(String(80),nullable=False)
    request_id: Mapped[str]=mapped_column(String(80),nullable=False,unique=True)
    received_ns: Mapped[int]=mapped_column(Integer,nullable=False)
    __table_args__=(Index('ix_arrival_run','run_id'),)


class RiskAdjustedExposure(Base):
    __tablename__='risk_adjusted_exposures'
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    institution: Mapped[str]=mapped_column(String(80),nullable=False)
    district: Mapped[str]=mapped_column(String(80),nullable=False)
    base_exposure: Mapped[float]=mapped_column(Float,nullable=False)
    risk_category: Mapped[str]=mapped_column(String(10),nullable=False)
    multiplier: Mapped[float]=mapped_column(Float,nullable=False)
    adjusted_exposure: Mapped[float]=mapped_column(Float,nullable=False)
    data_hash: Mapped[str]=mapped_column(String(64),nullable=False)
    updated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,nullable=False)
    __table_args__=(UniqueConstraint('institution','district',name='uq_risk_exposure_institution_district'),)

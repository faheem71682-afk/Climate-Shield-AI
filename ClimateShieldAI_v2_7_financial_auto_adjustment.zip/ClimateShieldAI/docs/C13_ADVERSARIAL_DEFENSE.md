# C13 — Adversarial Model / Logic Evasion (Model & Heuristic Defense)

**Threat:** an adversary subtly manipulates *non-critical* features to slip just beneath a detection / verification threshold.
**Asset:** the climate risk classifier (`LOW` < 35 ≤ `MEDIUM` < 65 ≤ `HIGH`) behind `POST /api/climate/predict`.

## 1. Blind spot identified
`climate_rule_baseline` is additive with hard cut-offs. Rainfall (45 pts) and river level (30 pts) are the critical flood drivers;
humidity (15 pts) and temperature (10 pts) are auxiliary. Pydantic validates each field *independently*, so any combination of
in-range values is accepted. Two consequences:

| # | Blind spot | Example (rain / temp / humidity / river) | Baseline |
|---|------------|------------------------------------------|----------|
| 1 | **Threshold hugging** — a few points of auxiliary input flips the category | 150 / 32 / **78→74** / 7 : truth HIGH (66.0) | 64.8 **MEDIUM** |
| 2 | **Dilution** — zeroing auxiliary inputs hides strongly elevated flood drivers | 160 / **32→25** / **85→40** / 8 : truth HIGH (73.3) | 60.0 **MEDIUM** |
| 3 | **No cross-feature plausibility check** — 160 mm of rain with 40 % humidity is physically implausible but accepted | same as #2 | accepted |
| 4 | **Free oracle** — the endpoint returns a 0.1-precision score, so a client can binary-search the cut-off | — | undetected |

## 2. Defensive validation boundary (`app/defense.py`)
Fail-safe by construction: every layer can only **raise** a category, never lower it.

1. **Physical-consistency clamp** — rain ≥ 100 mm ⇒ humidity floor 70 %; rain ≥ 50 mm ⇒ floor 60 %. Flag `HUMIDITY_RAIN_INCONSISTENT`. (Clamped, not rejected: rejecting would hand an attacker a probe oracle and drop genuine sensor faults.)
2. **Perturbation-stability margin** — the score is also computed with humidity +10 pts and temperature +3 °C (`BUDGET`; max swing 4.2 pts). If that worst case lands in a higher category, the higher one is returned. Flag `NEAR_THRESHOLD_ESCALATED`.
3. **Critical-evidence floor** — rainfall + river ≥ 55 of 75 pts ⇒ `HIGH` regardless of auxiliary inputs. Flag `CRITICAL_EVIDENCE_FLOOR`.
4. **Boundary-probing detector** — ≥ 6 *distinct* near-threshold readings from one client within 5 min ⇒ `BOUNDARY_PROBING_SUSPECTED`, `review_required`, and a `C13_DEFENSE_TRIGGERED` audit event. Identical retries count once; memory is bounded.

**Guarantee.** If a submission x′ differs from the true reading x only by lowering humidity ≤ 10 pts and temperature ≤ 3 °C, then
`hardened_category(x′) ≥ baseline_category(x)`. Proof sketch: the baseline is monotone non-decreasing in every feature; the margin
evaluates x′ at (humidity′+10, temperature′+3) ≥ (humidity, temperature) (clamps at 100/60 never go below the true value), so its
score ≥ the baseline score of x. Verified by a 20 000-case randomized test and an exhaustive sweep.

## 3. Before / after (raw output: `docs/c13_run_output.txt`)
| Scenario | Truth | BEFORE | AFTER |
|---|---|---|---|
| Humidity 78→74 | HIGH | 64.8 MEDIUM | 64.8 **HIGH** (`NEAR_THRESHOLD_ESCALATED`) |
| Humidity 85→40, temp 32→25 | HIGH | 60.0 MEDIUM | 66.0 **HIGH** (`HUMIDITY_RAIN_INCONSISTENT`) |
| Humidity 60→59 at the 35 cut-off | MEDIUM | 34.7 LOW | 35.0 **MEDIUM** |
| Humidity 80→72, temp 36→34 | HIGH | 64.2 MEDIUM | 64.2 **HIGH** |
| Control: benign low reading | LOW | 5.2 LOW | 5.2 LOW (no flags) |

Automated attacker, in budget (9 572 honest MEDIUM/HIGH readings × every humidity/temperature shave, 421 168 attempts):
**986 evaded before (10.3 %) → 0 after (0.0 %).**

## 4. Honest limits
* **Out-of-budget attacks are only partly stopped.** A shave of humidity −40 / temperature −10 evades in 27.6 % of cases before and **9.0 % after**. Example: 95 mm / 40 °C / 95 % / 10 m, truth HIGH, submitted at humidity 45 and temperature 28 ⇒ still MEDIUM (below the rain-based humidity floor and the 55-pt critical floor). Mitigation is the probing detector and, properly, authenticated sensor data — an unauthenticated client can simply lie about *rainfall* too, which this control does not address.
* **Cost:** on the evaluation grid the category is raised for 13.9 % of readings (more cautious, never less). The grid is uniform, not a real-world distribution; measure the raise rate on real NASA POWER data before tuning `BUDGET`.
* The 4.2-pt budget, humidity floors and the 55-pt floor are expert-set constants for a heuristic baseline, not fitted values. A trained model needs its own robustness testing (e.g. adversarial training / certified bounds); this boundary should stay in front of it.
* The raw 0.1-precision score is still returned (blind spot #4 is *detected*, not removed). Rounding scores to coarse bands would cut oracle leakage further at a UX cost.
* The detector is per-process and keyed by client IP; behind a proxy, configure trusted forwarded headers, and rate-limit at the gateway.

## 5. Reproduce
* `python scripts/c13_adversarial_test.py` — no server or third-party packages needed; exit code 0 = PASS.
* Dashboard → **C13 evasion defense** → *Run C13 evasion test* (`POST /api/c13/self-test`, coarse grid).
* `pytest -q` — `tests/test_core.py` (`test_c13_*`).

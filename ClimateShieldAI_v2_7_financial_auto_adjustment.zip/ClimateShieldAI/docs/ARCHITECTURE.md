# Architecture and security notes

## Request path
Browser/dashboard → FastAPI → Pydantic schema validation → API-key gate for state-changing endpoints → SQLAlchemy → SQLite (development) / PostgreSQL (deployment).

## C02 atomicity invariant
`actions` has a database unique constraint on `(scope, idempotency_key)`. The database, not an in-process Python lock, decides the winner. Each request hashes its action payload. Reusing a key with an identical payload is rejected as a duplicate; reusing it with a different payload returns HTTP 409. This remains meaningful across multiple API workers when all workers share the same PostgreSQL database.

## Arrival-window evidence
`/api/c02/arrival` stores `time.perf_counter_ns()` at API ingress. `/api/c02/runs/{run_id}` calculates max-minus-min server-observed arrival time. The external script reports both the server spread and the atomic action results. Client launch duration alone is not accepted as evidence.

## Input integrity
Pydantic rejects extra fields, malformed district/institution names, out-of-range values, NaN and infinity. SHA-256 is a fingerprint, not encryption or proof of source authenticity. For production, authenticate data providers and sign ingestion manifests.

## Audit integrity limitation
Each event stores the previous event hash and its own hash. The verifier recomputes each event hash from persisted canonical fields and checks pointer continuity. Periodically anchor the chain head in a separately controlled system; a database administrator could otherwise rewrite the entire chain.

## C07 error and information-leakage defense
`app/errors.py` installs (1) generic handlers for HTTPException, RequestValidationError and Exception, and (2) an outermost pure-ASGI `HardenedErrorMiddleware` that catches anything raised by any layer, strips server-identifying headers and returns a generic body. Each failure gets an opaque `ERR-<12 hex>` ID; the full trace is written only to the rotating JSON-lines `logs/error_audit.log`. Limitations: the log is plain files (use owner-only permissions and central shipping); the `Server` header added by uvicorn/hypercorn at the protocol layer must be disabled via server flags; error IDs are random and not authenticated, so they only help correlation, not authorization.

## C13 adversarial model / logic evasion defense
`app/defense.py` wraps the rule baseline in a validation boundary that is monotone-safe (it can raise but never lower a category): humidity/rain plausibility clamp, worst-case perturbation margin over a bounded auxiliary-feature budget, critical-evidence floor, and a bounded in-memory boundary-probing detector. `app/c13_eval.py` replays named attacks and an exhaustive in-budget attacker sweep against both the raw baseline and the hardened model; it backs `scripts/c13_adversarial_test.py` and `POST /api/c13/self-test`. Limitations: constants are heuristic, out-of-budget manipulation and falsified critical features are not covered, and the detector is per-process. Details: `docs/C13_ADVERSARIAL_DEFENSE.md`.
